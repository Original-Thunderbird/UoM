load trainBowData;
load testBowData;
load trainImageFilename;
load testImageFilename;

% Configure script
classNum = 3;
neighbourNum = 9;
visualise = false; % Change to visualise=true to see visualisation result
className = {'car', 'cow', 'motorbike'}; % Must match training order
validImageNum = size(testBowImage, 2);

% Scale feature vector - preprocessing data, so that the features
% are uniformaly spreaded in the Eucleanding space. (To increase
% robustness of L2 distance used during nearest neighbour finding).
w = std(trainBowImage, [], 2);
trainBowImage = bsxfun(@rdivide, trainBowImage, w);
testBowImage = bsxfun(@rdivide, testBowImage, w);

% For each validation data, run the classifier, and count errors
classPrior = computeClassCount(trainImageCat, classNum);

errCount = 0;

for i = 1 : validImageNum
    [classLabel, like, neighbour] = ...
        nearestClassifier(testBowImage(:, i), ...
                          trainBowImage, ...
                          trainImageCat, ...
                          classNum, ...
                          classPrior, ...
                          neighbourNum);                               
    if (classLabel ~= testImageCat(i))
        errCount = errCount + 1;
        fprintf('Failed, %s detected as %s, expected %s\n', ...
                testImageFilename{i}, ...
                className{classLabel}, className{testImageCat(i)});
    elseif (visualise)
        fprintf('This is a %s\n', className{classLabel});
    end
    % Visualise result
    if (visualise)
        figure(1);
        imshow(testImageFilename{i});
        figure(2);
        % Grid size
        r = floor(sqrt(neighbourNum));
        c = floor(neighbourNum / r + 0.5);
        for j = 1 : neighbourNum            
            subplot(r, c, j);
            imshow(trainImageFilename{neighbour(j)});
        end
        pause;
    end
end

fprintf('Error rate: %d out of %d failed.\n', errCount, validImageNum);

