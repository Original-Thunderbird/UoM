load trainSiftData;

codebookSize = 128;

% Seed before kmeans, so that kmeans is traceble. 
rng(133);
[codebookClusterLabel, codebookCluster] = ...
    kmeans(trainSift', codebookSize);

codebookCluster = codebookCluster'; % kmeans returns column major data

save('rawCodebook.mat', 'codebookClusterLabel', 'codebookCluster');