% A script to prepare program 
% Add an efficient 3rd party sift implementaion, but needs to compile it
addpath 3rdparty/sift;
if (~(exist('imsmooth', 'file') == 3))
    fprintf('Missing local file, try to compile SIFT package\n');
    cd 3rdparty/sift;
    sift_compile;
    cd ../..;
else
    fprintf('Found hint of locally compiled SIFT, skip compilation\n');
end
