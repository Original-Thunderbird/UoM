function [classLabel, vote, neighbour] = nearestClassifier(z, ...
                                                           x, ...
                                                           target, ...
                                                           classNum, ...
                                                           classPrior, ...
                                                           k)
% Classify a label for Z given features X, and corresponding target.
% nearestClassifier uses the same label for z as the feature has the
% nearest L2 distance in X.
% Z p-by-n matrix, n samples, each sample is a p-by-1 vector
% X p-by-m matrix, features
% target length m vector stores target value for X
% k number of neighbours to use [default=9]
% return classLabel - most likeliy candidate
% return vote - distribution of class label voted by nearest k neighbours
% neighbour - sorted order of all targets
if (nargin <= 5)
    k = 9;
end

distZX = dist(x', z);
[~, neighbour]= sort(distZX);

topVote = neighbour(1:k);

% get vote
classVote = target(topVote);

% Assum class id are integers from (1..N)
vote = hist(classVote, 1:classNum) ./ k;

% Apply Baye's to normalise vote, i.e. to get p(x|c) 
% Assume p(x) is some constant value. 
vote = vote ./ classPrior;

% Normalise vote so that it add up to 1 (Not neccessary, but will
% make output look nicer.
vote = vote ./ sum(vote);

% Find max vote
[~, classLabel] = max(vote);
end