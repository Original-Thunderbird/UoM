load trainBowData;
load trainImageFilename;
load rawCodebook;

% Configure script
classNum = 3; % Number of classes, default = 3, for car, cow, and motorbike.
voteNum = 9; % Choose nearest 9 neighbours to vote class id.
className = {'car'; 'cow'; 'motorbike'}; % Must match training order
minImageScale = 200 * 200; % Scale user input to a unit size

% Get data, and learn weightning factor for training set.
weight = std(trainBowImage, [], 2);
featTrain = bsxfun(@rdivide, trainBowImage, weight);
targTrain = trainImageCat;

% Your image goes here
imagePath = '';

if (isempty(imagePath))
    fprintf('You have not set test image path...A demo image will be used.\n');
    imagePath = 'test-images/motorbike/00054.jpg';
end

[testImage, grayImage] = readClearImage(imagePath, minImageScale);

[~, desc] = sift(grayImage);
h = bowHistL2(desc, codebookCluster, 0.7);
% Normalise data
featTest = h' ./ weight;
prior = computeClassCount(targTrain, classNum);
[prediction, like, neighbour] = ...
    nearestClassifier(featTest, featTrain, targTrain, classNum, prior, voteNum);

% Print vote distribution
fprintf('Test image was voted as a %s:\n', className{prediction});
for i = 1 : classNum
    fprintf('\tClass %s: %f\n', className{i}, like(i));
end

% Show result
figure(1);
imshow(testImage);
figure(2); % Show top nine matches
for j = 1 : 9
    subplot(3, 3, j);
    imshow(imread(trainImageFilename{neighbour(j)}));
end
