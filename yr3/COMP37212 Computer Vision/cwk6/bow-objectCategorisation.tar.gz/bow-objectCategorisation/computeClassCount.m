function classCount = computeClassCount(labels, classNum)
% Compute class prior given labels. Assume class id starts from 1
h = hist(labels, 1:classNum);
classCount = h ./ length(labels);
end