function [fileName] = listImageFiles(pathName, imageExt)
% A utility to find images in a directory by matching file extensions
if (nargin == 1)
    imageExt = 'jpg';
end

slash = '/';
if (pathName(end) == '/')
    slash = '';
end

pattern = [pathName, slash, '*.', imageExt];
result = dir(pattern);

fileName = cell(length(result), 1);
for i = 1 : length(result)
    fileName{i} = [pathName, slash, result(i).name];
end

end