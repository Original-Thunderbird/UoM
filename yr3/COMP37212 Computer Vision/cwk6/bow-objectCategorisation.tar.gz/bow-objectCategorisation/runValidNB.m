load testBowData;
load testImageFilename;

load naiveBayesModel;

% Script configuration
classNum = 3;
className = {'car'; 'cow'; 'motorbike'}; % Must match training order

% Run the script, count errors for all validation image set
err = 0;

imageNum = size(testBowImage, 2);

for i = 1 : imageNum
    classId = naiveBayesClassifier(testBowImage(:, i), ...
                                   naiveBayesModel, ...
                                   classNum);
    if (classId ~= testImageCat(i))
        err = err + 1;
        fprintf('Failed, %s, detected as %s, expected %s\n', ...
                testImageFilename{i}, className{classId}, ...
                className{testImageCat(i)});
    end
end

fprintf('Error rate: %d out of %d failed.\n', err, imageNum);