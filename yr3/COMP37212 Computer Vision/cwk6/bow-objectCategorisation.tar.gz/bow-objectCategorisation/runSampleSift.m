% For a list of files, sample patches, and store result in a file

load trainImageFilename;
rng(90); % Seed random generator

maxImageNum = 148; % number of images to sample
maxSift = 100; % for each image, sample at most 100 descriptors

rawPatchSize = 25; % RawPatch

fileNum = length(trainImageFilename);

ind = randperm(fileNum);
ind = ind(1:maxImageNum); 

trainFile = trainImageFilename(ind);
count = 0;
maxTotal = maxImageNum * maxSift;
trainSift = zeros(128, maxTotal);

for i = 1 : length(trainFile)
    % Sample sift, and raw patches
    [desc] = extractSift(trainFile{i}, rawPatchSize);
    descNum = size(desc, 2);
    siftInd = randperm(descNum);
    siftInd = siftInd(1:maxSift);
    trainSift(:, count+1:count+maxSift) = desc(:, siftInd);
    count = count+maxSift;    
end

save('trainSiftData.mat', 'trainSift');