load trainImageFilename;
load testImageFilename;
load rawCodebook;

% Script configuration
rejectDist = 0.7;

% Scan train-images
imageNum = length(trainImageFilename);
codebookSize = size(codebookCluster, 2);

bowImage = zeros(codebookSize, imageNum);

for i = 1 : imageNum
    img = imread(trainImageFilename{i});
    if (size(img, 3) == 3)
        img = rgb2gray(img);
    end
    [~, desc] = sift(img);
    bowImage(:, i) = bowHistL2(desc, codebookCluster, rejectDist);
end

trainBowImage = bowImage;
save('trainBowData.mat', 'trainBowImage');

% Scan test-images
imageNum = length(testImageFilename);
codebookSize = size(codebookCluster, 2);

bowImage = zeros(codebookSize, imageNum);

for i = 1 : imageNum
    img = imread(testImageFilename{i});
    if (size(img, 3) == 3)
        img = rgb2gray(img);
    end
    [~, desc] = sift(img);
    bowImage(:, i) = bowHistL2(desc, codebookCluster, rejectDist);
end

testBowImage = bowImage;
save('testBowData.mat', 'testBowImage');