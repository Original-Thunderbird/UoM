prepare;
runScanImages; % Script to get all image patches
runSampleSift; % Sample sift descriptors
runTrainCodebook;
runExamTrainImageL2; % Describe images using trained bag-of-words
runTrainNB; % Train naive bayes classifier
runValidNB; % validate naive bayes
runValidNearestClassifier; % validate nearest neighbour classifier