% Scan images, and store every filenames to a file
scanTrainDir = {'train-images/car', 'train-images/cow', 'train-images/motorbike'};
scanTestDir = {'test-images/car', 'test-images/cow', 'test-images/motorbike'};
trainImageFilename = {};
trainImageCat = [];
testImageFilename = {};
testImageCat = [];

rng(49);

for i = 1 : length(scanTrainDir)
    imageList = listImageFiles(scanTrainDir{i});        
    imageNum = numel(imageList);
    trainImageFilename = cat(1, trainImageFilename, imageList);
    trainImageCat = cat(1, trainImageCat, ones(imageNum, 1) * i);
end

% save('imageFilename.mat', 'imageFilename', 'imageCat');
save('trainImageFilename.mat', 'trainImageFilename', 'trainImageCat');

for i = 1 : length(scanTestDir)
    imageList = listImageFiles(scanTestDir{i});        
    imageNum = numel(imageList);
    testImageFilename = cat(1, testImageFilename, imageList);
    testImageCat = cat(1, testImageCat, ones(imageNum, 1) * i);
end

% save('imageFilename.mat', 'imageFilename', 'imageCat');
save('testImageFilename.mat', 'testImageFilename', 'testImageCat');