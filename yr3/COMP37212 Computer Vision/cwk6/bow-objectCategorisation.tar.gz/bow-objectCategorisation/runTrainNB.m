load trainBowData;
load trainImageFilename;

fprintf('Training a Naive Bayes classifier\n');

% Define number of class
classNum = 3; 

% Derive statistics for NB from training data
codebookSize = size(trainBowImage, 1);

% Probablility of P(c|w_i)
prCW = zeros(codebookSize, classNum);

% Learn prCW
for i = 1 : classNum
    % Select class i
    selected = (trainImageCat == i);
    prCW(:, i) = sum(trainBowImage(:, selected), 2);
end

% Get sum of all votes
totalVote = sum(prCW, 2);
votePrior = totalVote ./ sum(totalVote);

% Normalise prCW so that it is a probablity function
prCW  = bsxfun(@rdivide, prCW, sum(prCW, 2));

% Compute class prior
classPrior = computeClassCount(trainImageCat, classNum);

% Now we can derive p(w_i|c) for each class
naiveBayesModel = zeros(size(prCW));
for i = 1 : classNum
    naiveBayesModel(:, i) = prCW(:, i) .* votePrior ./ classPrior(i);
end

save 'naiveBayesModel.mat' 'naiveBayesModel'
