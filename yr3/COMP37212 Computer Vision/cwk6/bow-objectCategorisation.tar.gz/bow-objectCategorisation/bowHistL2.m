function h = bowHistL2(imageDesc, codebook, th)

% Matching descriptors using L2 distance
numOfBins = size(codebook, 2);
distExam = dist(imageDesc', codebook);
[minValue, minMatch] = min(distExam, [], 2);
minMatch = minMatch(minValue < th);
h = hist(minMatch, 1:numOfBins) ./ length(minMatch);

end