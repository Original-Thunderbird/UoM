function [descriptor, patch] = extractSift(arg1, rawPatchSize)
% Extract sift descriptors from an image, returns a 128xN feature 
% descriptor matrix, and a MxN raw patches sampled in the image.
% The raw patch will first be sampled according to SIFT configuration,
% and then resized to rawPatchSize specified by user (25 by default)
if (nargin <= 1)
    rawPatchSize = 25;
end

if (ischar(arg1))
    img = imread(arg1);
else
    img = arg1;
end

if (size(img, 3) ~=1)        
    img = rgb2gray(img);
end

[frame, descriptor] = sift(img);
if nargout == 1
    return;
end
siftNum = size(frame, 2);
patchDim1 = rawPatchSize * rawPatchSize;
patch = zeros(patchDim1, siftNum);
[height, width] = size(img);
for i = 1 : siftNum
    x = floor(frame(1, i) + 0.5);
    y = floor(frame(2, i) + 0.5);
    scale = floor(3 * frame(3, i) + 0.5);
    theta = frame(4, i);
    
    % Extract a patch
    co = x - scale : x + scale;
    ro = y - scale : y + scale;
    rawSize = length(co);
    rawInd = 1 : rawSize;
    raw = zeros(rawSize, rawSize);
    % weight = fspecial('gaussian', size(raw), 1.5 * frame(3, i));
    % weight = weight ./ max(weight(:));
    selected = co > 0 & co < width & ro > 0 & ro < height;
    co = co(selected);
    ro = ro(selected);
    raw(rawInd(selected), rawInd(selected)) = img(ro, co);
    % raw = raw .* weight;
    raw = imresize(raw, [rawPatchSize, rawPatchSize]);
    raw = imrotate(raw, -theta * 180 / pi, 'crop');
    patch(:, i) = raw(:);
end

end