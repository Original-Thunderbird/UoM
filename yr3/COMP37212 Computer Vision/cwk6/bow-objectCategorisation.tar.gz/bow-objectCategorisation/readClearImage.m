function [img, gray] = readClearImage(imgPath, scale)
% Read image and check against a required scale. If the image is too small
% it will be rejected, and throw an error. If it is accepted, it will
% be scaled to a safe size which will allow sift run fast while keep
% enough visual details.
img = imread(imgPath);
[wd, hi, ch] = size(img);
if (wd * hi < scale * 0.5)
    error('Input image is too small to provide enough visual features');
end

factor = sqrt(scale / (wd*hi));

img = imresize(img, factor);

if (ch > 1)
    gray = rgb2gray(img);
else
    gray = img;
end

end