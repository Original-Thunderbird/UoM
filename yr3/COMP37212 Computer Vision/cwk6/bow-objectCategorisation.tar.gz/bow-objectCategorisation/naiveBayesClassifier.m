function [classId, like] = ...
    naiveBayesClassifier(feature, nbModel, classNum)

like = zeros(classNum, 1);
for i = 1 : classNum
    like(i) = prod(nbModel(:, i) .^ feature);
end

% Normalise likelihood so that it add up to 1 (Not neccessary, but will
% make output look nicer.
like = like ./ sum(like);

[~, classId] = max(like);

end