load naiveBayesModel;
load rawCodebook;

% Script configuration
classNum = 3;
className = {'car', 'cow', 'motorbike'}; % Must match the training order.
minImageScale = 200 * 200; % Scale user input to a unit size
% Your image path goes here
imagePath = '';
if (isempty(imagePath))
    fprintf('Image path is empty...A demo image will be used.\n');
    imagePath = 'test-images/motorbike/00054.jpg';
end

[testImage, grayImage] = readClearImage(imagePath, minImageScale);
figure(1);
imshow(testImage);
[~, desc] = sift(grayImage);

feature = bowHistL2(desc, codebookCluster, 0.7)';

[classId, like] = naiveBayesClassifier(feature, naiveBayesModel, classNum);

fprintf('Test image could be a %s:\n', className{classId});
for i = 1 : classNum
    fprintf('\t%s: %f\n', className{i}, like(i));
end