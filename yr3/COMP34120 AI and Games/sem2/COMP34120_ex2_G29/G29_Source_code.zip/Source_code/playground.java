import org.apache.commons.math3.stat.regression.*;
import org.apache.commons.math3.linear.AbstractRealMatrix;
import org.apache.commons.math3.linear.Array2DRowRealMatrix;
import org.apache.commons.math3.linear.BlockRealMatrix;
import org.apache.commons.math3.linear.MatrixUtils;

public class playground {
    public static void main(String[] args) {
//        SimpleRegression regression = new SimpleRegression();
        double[][][] data = {{{3},{2}}, {{4},{3}}, {{5},{3}}, {{6},{4}}, {{7},{6}}};
//        regression.addData(data);
//        System.out.println("slope = " + regression.getSlope());
//        System.out.println("intercept = " + regression.getIntercept());
//        System.out.println("standard error = " + regression.getSlopeStdErr());

//        BlockRealMatrix p = new BlockRealMatrix(2,2);
//        BlockRealMatrix theta = new BlockRealMatrix(2,1);
//        BlockRealMatrix phi_x, p_add_factor, theta_add_factor;
//        for (int day = 0; day < 5; day++) {
//            phi_x = new BlockRealMatrix(data[day]);
//            p_add_factor = (BlockRealMatrix)(phi_x.multiply((BlockRealMatrix)phi_x.transpose()).scalarMultiply(0.5));
//            System.out.println("p_add_factor:"+p_add_factor.toString());
//
//            theta_add_factor = (BlockRealMatrix)(phi_x.scalarMultiply(0.5));
//            System.out.println("theta_add_factor:"+theta_add_factor.toString());
//
//            p = p.add(p_add_factor);
//            System.out.println("p:"+p.toString());
//
//            theta = theta.add(theta_add_factor);
//            System.out.println("theta:"+theta.toString()+"\n");
//        }
//        System.out.println("p:"+p.toString());
//        theta = (BlockRealMatrix)(MatrixUtils.inverse(p)).multiply(theta);
//        System.out.println("theta:"+theta.toString());
//        double[][] vector_from_theta = theta.getData();
//        System.out.println("a:"+vector_from_theta[0][0]+",b:"+vector_from_theta[1][0]);

        double[][] p_constructor = { {0.2,0.3}, {0.4,0.5} };
        BlockRealMatrix p = new BlockRealMatrix(p_constructor);
        BlockRealMatrix phi_x = new BlockRealMatrix(data[1]);
        BlockRealMatrix result = ((BlockRealMatrix)(phi_x.transpose())).multiply(p).multiply(phi_x);
        System.out.println("result:"+result.toString());
        System.out.println("inside:"+result.getData()[0][0]);
    }
}