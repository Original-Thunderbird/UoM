
/*
 * nehegl.cpp - opengl framework
 * ҹ�� 2011.11.11
*/

#include <Windows.h>
#include <gl/GL.h>   // header file for the opengl32 library
#include <gl/GLU.h>  // header file for the glu32 library
#include "nehegl.h"
#include "fps.h"

#define WM_TOGGLEFULLSCREEN (WM_USER + 1) // application define message for toggling

bool g_bapploop;    // window creation loop, for full screen / windowed toggle
bool g_bfullscreen; // if false, then create full screen
DEVMODE g_saved_devmode;

int mouse_x, mouse_y; // the current position of the mouse

FPS* FPS::instance_ = NULL;
FPS* FPS::Instance(){
   if (instance_ == 0) {
      instance_ = new FPS;
   }
   return instance_;
}

// terminate the application
void TerminateApplication (GLWindow* glwin) {
   PostMessage(glwin->hwnd, WM_QUIT, 0, 0);
   g_bapploop = false;
}

// toggle fullscreen / windowed mode
void ToggleFullscreen (GLWindow* glwin) {
   PostMessage(glwin->hwnd, WM_TOGGLEFULLSCREEN, 0, 0);
}

// resize and initialize the GL window
void ResizeGLScene(GLsizei width, GLsizei height) {
   if (height == 0) { // prevent a divide by zero
      height = 1;
   }

   glViewport(0, 0, width, height); // reset the current viewport

   glMatrixMode(GL_PROJECTION);  // select the projection matrix
   glLoadIdentity();             // reset the projection matrix

   gluPerspective(45.0f, (float)width/(float)height, 0.1f, 100.0f);// calculate the aspect ratio of the window

   glMatrixMode(GL_MODELVIEW);   // select the modelview matrix
   glLoadIdentity();             // reset the modelview matrix
}

// change the screen resolution
// w: width,  h: height,  bpp: bytes per pixel
bool ChangeScreenResolution(int w, int h, int bpp) {
   DEVMODE devmode;
   memset(&devmode, 0, sizeof(devmode)); // make sure memory's cleared
   devmode.dmSize       = sizeof(devmode);
   devmode.dmPelsWidth  = w; // selected screen width
   devmode.dmPelsHeight = h; // selected screen height
   devmode.dmBitsPerPel = bpp; // selected bits per pixel
   devmode.dmFields     = DM_PELSWIDTH | DM_PELSHEIGHT | DM_BITSPERPEL;

   // try to set selected mode and get results. note: CDS_FULLSCREEN get rid of start bar.
   if (ChangeDisplaySettings(&devmode, CDS_FULLSCREEN) != DISP_CHANGE_SUCCESSFUL) {
      return false;
   }
   return true;
}

// properly kill the window
GLvoid KillGLWindow(GLWindow* glwin) {
   if (glwin->init.fullscreen) {
      //ChangeDisplaySettings(NULL, 0); // switch back to the desktop
      if (!ChangeDisplaySettings(NULL, CDS_TEST)){ // if the shortcut doesn't work
         ChangeDisplaySettings(NULL, CDS_RESET); // do ti anyway (to get the values out of the registry)
         ChangeDisplaySettings(&g_saved_devmode, CDS_RESET); // change it to the saved settings
      }
      else {
         ChangeDisplaySettings(NULL, CDS_RESET); // if it works, go right ahead
      }
   }
   ShowCursor(TRUE);

   if (!wglMakeCurrent(0, 0)) { // are we able to release the DC and RC ?
      MessageBox(NULL, "Release of DC and RC Failed.", "ShutDown Error", MB_OK | MB_ICONINFORMATION);
   }

   if (glwin->hrc && !wglDeleteContext(glwin->hrc)) { // do we have a rendering context ? // are we able to delete the RC ?
      MessageBox(NULL, "Release Rendering Context Failed.", "ShutDown Error", MB_OK | MB_ICONINFORMATION);
      glwin->hrc = 0;
   }

   if (glwin->hdc && !ReleaseDC(glwin->hwnd, glwin->hdc)) { // are we able to release the DC ?
      MessageBox(NULL, "Release Device Context Failed.", "ShutDown Error", MB_OK | MB_ICONINFORMATION);
      glwin->hdc = 0;
   }

   if (glwin->hwnd && !DestroyWindow(glwin->hwnd)) { // are we able to destroy the window ?
      MessageBox(NULL, "Could Not Release hwnd.", "ShutDown Error", MB_OK | MB_ICONINFORMATION);
      glwin->hwnd = 0;
   }
}

// bits: 16/24/32
BOOL CreateGLWindow(GLWindow* glwin) {
   EnumDisplaySettings(NULL, ENUM_CURRENT_SETTINGS, &g_saved_devmode);// save the current display state

   DWORD style, exstyle; // window style, extended style.
   if (glwin->init.fullscreen) {
      if (ChangeScreenResolution(glwin->init.width, glwin->init.height, glwin->init.bpp)) {
       style    = WS_POPUP;
       exstyle  = WS_EX_APPWINDOW;// forces a top-level window onto the taskbar when the window is visible.
         ShowCursor(FALSE);
      }
      else {
         // if the mode fails, offer two options, quit or run in a window.
         if (MessageBox(NULL, 
            "The Requested Fullscreen Mode Is Not Supported By/On Your Video Card. Use Windowed Mode Instead ?", 
            glwin->init.title, MB_YESNO | MB_ICONEXCLAMATION) == IDYES) {
               glwin->init.fullscreen = false;
         }
         else {
            MessageBox(NULL, "Program Will Now Close.", "CreateGLWindow Error", MB_OK | MB_ICONSTOP);
            return FALSE;
         }
      }
   }

   if (!glwin->init.fullscreen) {
      style    = WS_OVERLAPPEDWINDOW;
      exstyle  = WS_EX_APPWINDOW | WS_EX_WINDOWEDGE;
   }
   RECT winrect = {0, 0, glwin->init.width, glwin->init.height};
   AdjustWindowRectEx(&winrect, style, FALSE, exstyle); // adjust window to requested size

   if ( !(glwin->hwnd = CreateWindowEx(exstyle, // extended style for the window
      glwin->init.app->classname,
      glwin->init.title,
      WS_CLIPSIBLINGS | WS_CLIPCHILDREN | style, // style, WS_CLIPSIBLINGS | WS_CLIPCHILDREN prevent other windows from drawing over or into our OpenGL Window.
      0, 0, // window position
      winrect.right - winrect.left, // calculate adjusted window width
      winrect.bottom - winrect.top, // calculate adjusted window height
      NULL,    // no parent window
      NULL,    // no menu
      glwin->init.app->hinst, // instance
      glwin)) ) {
         MessageBox(NULL, "CreateWindowEx Error.", "CreateGLWindow Error", MB_OK | MB_ICONEXCLAMATION);
         return FALSE;
   }

   if (!(glwin->hdc = GetDC(glwin->hwnd))) { // get a device context
      KillGLWindow(glwin);
      MessageBox(NULL, "Can't Create A GL Device Context.", "CreateGLWindow Error", MB_OK | MB_ICONEXCLAMATION);
      return FALSE;
   }

   GLuint pixelformat;
   PIXELFORMATDESCRIPTOR pfd; // pfd tells windows how we want things to be
   pfd.nSize      = sizeof(PIXELFORMATDESCRIPTOR); // size
   pfd.nVersion   = 1;                             // version number
   pfd.dwFlags    = PFD_DRAW_TO_WINDOW | PFD_SUPPORT_OPENGL | PFD_DOUBLEBUFFER;// format must support window/ opengl/ double buffering
   pfd.iPixelType = PFD_TYPE_RGBA;  // request an rgba format
   pfd.cColorBits = glwin->init.bpp;// select our color depth
   pfd.cRedBits   = 0;              // color bits ignored
   pfd.cRedShift  = 0;
   pfd.cGreenBits = 0;
   pfd.cGreenShift= 0;
   pfd.cBlueBits  = 0;
   pfd.cBlueShift = 0;
   pfd.cAlphaBits = 0;              // no alpha buffer
   pfd.cAlphaShift= 0;              // shift bits ignored
   pfd.cAccumBits = 0;              // no accumulation buffer
   pfd.cAccumRedBits    = 0;        // accumulation bits ignored
   pfd.cAccumGreenBits  = 0;
   pfd.cAccumBlueBits   = 0;
   pfd.cAccumAlphaBits  = 0;
   pfd.cDepthBits       = 16;       // 16bit z-buffer(depth buffer)
   pfd.cStencilBits     = 0;        // no stencil buffer
   pfd.cAuxBuffers      = 0;        // no auxiliary buffer
   pfd.iLayerType       = PFD_MAIN_PLANE; // main drawing layer
   pfd.bReserved        = 0;              // reserved
   pfd.dwLayerMask      = 0;              // layer masks ignored
   pfd.dwVisibleMask    = 0;
   pfd.dwDamageMask     = 0;
   if (!(pixelformat = ChoosePixelFormat(glwin->hdc, &pfd))) { // find a matching pixel format
      KillGLWindow(glwin);
      MessageBox(NULL, "Can't Find A Suitable PixelFormat.", "CreateGLWindow Error", MB_OK | MB_ICONEXCLAMATION);
      return FALSE;
   }

   if (!SetPixelFormat(glwin->hdc, pixelformat, &pfd)) { // set the pixel format
      KillGLWindow(glwin);
      MessageBox(NULL, "Can't Set The PixelFormat.", "CreateGLWindow Error", MB_OK | MB_ICONEXCLAMATION);
      return FALSE;
   }

   if (!(glwin->hrc = wglCreateContext(glwin->hdc))) { // get a rendering context
      KillGLWindow(glwin);
      MessageBox(NULL, "Can't Create A GL Rendering Context.", "CreateGLWindow Error", MB_OK | MB_ICONEXCLAMATION);
      return FALSE;
   }

   if (!wglMakeCurrent(glwin->hdc, glwin->hrc)) { // active the rendering context
      KillGLWindow(glwin);
      MessageBox(NULL, "Can't Active The GL Rendering Context.", "CreateGLWindow Error", MB_OK | MB_ICONEXCLAMATION);
      return FALSE;
   }

   ShowWindow(glwin->hwnd, SW_SHOW);     // show the window
   glwin->visible = true;
   SetForegroundWindow(glwin->hwnd);     // slightly higher priority
   SetFocus(glwin->hwnd);                // sets keyboard focus to the window
   ResizeGLScene(glwin->init.width, glwin->init.height); // set up our perspective GL Scene
   return TRUE;
}

// deal with all the window messages
LRESULT CALLBACK WndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam) {
   GLWindow* glwin = (GLWindow*)(GetWindowLong(hWnd, GWL_USERDATA));

   switch (uMsg)
   {
   case WM_SYSCOMMAND:              // intercept system commands
      switch (wParam) {             // check system calls
         case SC_SCREENSAVE:           // screensaver trying to start ?
         case SC_MONITORPOWER:         // monitor trying to enter powersave ?
            return 0;                  // prevent from happening
      }
      break;

   case WM_CREATE:
      {
         CREATESTRUCT* creation = (CREATESTRUCT*)(lParam);
         glwin = (GLWindow*)(creation->lpCreateParams);
         SetWindowLong(hWnd, GWL_USERDATA, (LONG)(glwin));
      }
      return 0;

   case WM_CLOSE:                   // receive a close message
      TerminateApplication(glwin);  // terminate application
      return 0;                     // jump back

   case WM_SIZE:
      switch (wParam) {
      case SIZE_MINIMIZED:
         glwin->visible = false;
         return 0;

      case SIZE_MAXIMIZED:
      case SIZE_RESTORED:
         glwin->visible = true;
         ResizeGLScene(LOWORD (lParam), HIWORD (lParam));
         return 0;
      }
      break;

   case WM_KEYDOWN:                 // key being hold down
      if (wParam >= 0 && wParam <= 255) {
         glwin->keys[wParam] = true;// mark is as true
         return 0;
      }
      break;

   case WM_KEYUP:                   // key been released
      if (wParam >= 0 && wParam <= 255) {
         glwin->keys[wParam] = false;// mark is as false
         return 0;
      }
      break;

   case WM_TOGGLEFULLSCREEN:
      g_bfullscreen = !g_bfullscreen;
      PostMessage (hWnd, WM_QUIT, 0, 0);
      break;

   case WM_LBUTTONDOWN:
      mouse_x = LOWORD(lParam);
      mouse_y = HIWORD(lParam);
      Selection();
      break;

   case WM_MOUSEMOVE:
      mouse_x = LOWORD(lParam);
      mouse_y = HIWORD(lParam);
      break;
   }

   // pass all unhandled messages to DefWindowProc
   return DefWindowProc(hWnd, uMsg, wParam, lParam);
}

bool RegisterWindowClass(App* app) {
   WNDCLASSEX wc;
   memset(&wc, 0, sizeof(WNDCLASSEX));
   wc.cbSize      = sizeof(WNDCLASSEX);
   wc.style       = CS_HREDRAW | CS_VREDRAW | CS_OWNDC; // redraw on move, and own DC for window
   wc.lpfnWndProc = (WNDPROC)WndProc;  // WndProc handles messages
   wc.cbClsExtra  = 0;
   wc.cbWndExtra  = 0;
   wc.hInstance   = app->hinst;
   wc.hIcon       = LoadIcon(NULL, IDI_APPLICATION);
   wc.hCursor     = LoadCursor(NULL, IDC_ARROW);
   wc.hbrBackground = NULL; // no background required, set that in GL
   wc.lpszMenuName  = NULL; // we don't want a menu
   wc.lpszClassName = app->classname;

   if (!RegisterClassEx(&wc)) { // attempt to register the window class
      MessageBox(NULL, "RegisterWindowClass Failed.", "Error", MB_OK | MB_ICONINFORMATION);
      return false;
   }
   return true;
}

// application entry point
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nShowCmd) {
   App      app;
   GLWindow glwin;
   MSG      msg;

   app.classname = "OpenGL";
   app.hinst     = hInstance;

   memset(&glwin, 0, sizeof(GLWindow));
   glwin.init.app        = &app;
   glwin.init.title      = "Night's OpenGL Framework";
   glwin.init.width      = 640;
   glwin.init.height     = 480;
   glwin.init.bpp        = 32;
   glwin.init.fullscreen = false;

   //if (MessageBox(NULL, "Would You Like To Run In Fullscreen Mode?", "Start FullScreen", MB_YESNO | MB_ICONQUESTION) == IDYES) {
   //   glwin.init.fullscreen = true;
   //}

   if (!RegisterWindowClass(&app)) {
      return -1;
   }

   g_bapploop = true;
   g_bfullscreen = glwin.init.fullscreen;
   while (g_bapploop) {
      glwin.init.fullscreen = g_bfullscreen;
      if (CreateGLWindow(&glwin)) {
         if (Initialize(&glwin)) {
            FPS::Instance()->reset();
            while (true) {
               if (PeekMessage(&msg, NULL, 0, 0, PM_REMOVE)) { // is there a message waiting ?
                  if (msg.message == WM_QUIT) { // received a quit message
                     break;
                  }
                  else {
                     TranslateMessage(&msg); // translate the message
                     DispatchMessage(&msg);  // dispatch the message
                  }
               }
               else { // there are no message
                  if (glwin.visible) {
                     int ret = FPS::Instance()->update();
                     if (ret == 0) {
                        if (!Update()) PostQuitMessage(0);// break;
                        if (!Draw()) PostQuitMessage(0);// break; // draw the scene
                        SwapBuffers(glwin.hdc);  // swap buffers (double buffering)
                     }
                     else if (ret == 1) {
                        Sleep(1);
                     }
                  }
                  else {
                     WaitMessage();
                  }
               }
            }
         }
         else {
            TerminateApplication(&glwin);
         }
         Deinitialize();
         KillGLWindow(&glwin);
      }
      else {
         g_bapploop = false;
      }
   }

   UnregisterClass(app.classname, app.hinst);
   return msg.wParam;// exit the program
}
