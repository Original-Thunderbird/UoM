
/*
 * nehegl.h - opengl framework
 * ҹ�� 2011.11.11
*/

#ifndef _NEHEGL_H_
#define _NEHEGL_H_

#include <Windows.h> // header file for windows

typedef bool Keys[256];

// application structure
typedef struct {
   HINSTANCE   hinst;
   const char*   classname;
} App;

typedef struct {   // window creation info
   App*  app;      // application structure
   char*   title;   // window title
   int   width;   // width
   int   height;   // height
   int   bpp;      // Bits Per Pixel
   bool  fullscreen;// full screen or windowed mode ?
} GLWinInit;       // GLWinInit

typedef struct {
   Keys        keys;     // Key Structure
   HWND        hwnd;     // Window Handle
   HDC         hdc;      // Device Context
   HGLRC       hrc;      // Rendering Context
   GLWinInit   init;     // Window Init
   bool        visible;  // Window Visible?
} GLWindow;              // GLWindow

void TerminateApplication(GLWindow* glwin); // terminate the application

void ToggleFullscreen(GLWindow* glwin); // toggle fullscreen / windowed mode

// These Are The Function You Must Provide
bool Initialize(GLWindow* glwin);   // performs all your initialization

void Deinitialize(void);  // performs all your deinitialization

bool Update();    // perform motion updates, dt is milliseconds

bool Draw(void);          // perform all your scene drawing

void Selection(void);     // perform selection

extern int mouse_x;
extern int mouse_y;

#endif // _NEHEGL_H_
