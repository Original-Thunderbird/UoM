
/*
 * fireworks.cpp
 * ҹ�� 2011.12.07
*/

#include <Windows.h>
#include <math.h>
#include <stdio.h>
#include <gl/GL.h>   // header file for the opengl32 library
#include <gl/GLU.h>  // header file for the glu32 library
#include <gl/glaux.h>// header file for the glaux library
#include "nehegl.h"
#include "fps.h"

#pragma comment(lib, "opengl32.lib")
#pragma comment(lib, "glu32.lib")
#pragma comment(lib, "glaux.lib")
#pragma comment(lib, "winmm.lib")

GLWindow* g_glwin;

bool g_brainbow = true; // rainbow mode on / off
bool g_sbpressed;       // spacebar pressed
bool g_rtpressed;       // return key pressed

float g_speed = 60.0f;  // particles move speed, 60 fps
float g_xspeed, g_yspeed, g_zoom = -40.0f;
GLuint g_currentcolor = 0;
GLuint g_delay;   // delay of rainbow effect
GLuint g_texnames[2];   // storage for two texture

const int MAX_FIRES = 5;       // ���5���̻�
const int MAX_PARTICLES = 24; // ÿ���̻�����ɢ����С�̻�����
const int MAX_TAILS = 30;      // �̻�β��

typedef struct {
   float r, g, b;      /* color */
   float x, y, z;      /* position  */
   float xs, ys, zs;   /* speed  */
   float xg, yg, zg;   /* gravity  */
   boolean up;         /* up or down */
} Particle;

typedef struct {
   Particle particle[MAX_PARTICLES][MAX_TAILS]; // �̻�ϵͳ����
   float life, fade, rad; // ������˥���ٶȣ�x-zƽ���ϵ��˶��ٶ�
} Fire;

Fire g_fires[MAX_FIRES];

static GLfloat colors[12][3] = { // Rainbow Of Colors
   {1.0f,0.5f,0.5f},{1.0f,0.75f,0.5f},{1.0f,1.0f,0.5f},{0.75f,1.0f,0.5f},
   {0.5f,1.0f,0.5f},{0.5f,1.0f,0.75f},{0.5f,1.0f,1.0f},{0.5f,0.75f,1.0f},
   {0.5f,0.5f,1.0f},{0.75f,0.5f,1.0f},{1.0f,0.5f,1.0f},{1.0f,0.5f,0.75f}
};

// loads a bitmap image
AUX_RGBImageRec* LoadBMP(char* filename) {
   if (filename == NULL) {
      return NULL;
   }

   FILE* file = NULL;
   if (fopen_s(&file, filename, "r") == 0) {
      fclose(file);
      return auxDIBImageLoad(filename);
   }
   return NULL;
}

 //load bitmap and convert to textures
 //The image height and width MUST be a power of 2. The width and height must be 
 //at least 64 pixels, and for compatability reasons, shouldn't be more than 256 
 //pixels. If the image you want to use is not 64, 128 or 256 pixels on the width 
 //or height, resize it in an art program. There are ways around this limitation, 
 //but for now we'll just stick to standard texture sizes.
int LoadGLTexture() {
   AUX_RGBImageRec* teximage[2]; // create storage space for the texture
   memset(teximage, 0, 2*sizeof(void*)); // set the pointer to NULL

   if (!(teximage[0] = LoadBMP("Data/particle.bmp")) ||
     !(teximage[1] = LoadBMP("Data/pearl.bmp"))) {
      return FALSE;
   }

   glGenTextures(2, g_texnames);// provide unused texture names
   for (int i = 0; i < 2; i++) {
     glBindTexture(GL_TEXTURE_2D, g_texnames[i]); // create a new texture object and assigned name
     glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
     glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
     glTexImage2D(GL_TEXTURE_2D, 0, 3, teximage[i]->sizeX, // define the texture
       teximage[i]->sizeY, 0, GL_RGB, GL_UNSIGNED_BYTE, teximage[i]->data);

     if (teximage[i]) {
       if (teximage[i]->data) {
         free(teximage[i]->data);
       }
       free(teximage[i]);
     }
   }
   return TRUE;
}

void ResetFire(int loop) {
   // init position
   float xtemp = rand()%22 - 11.f;
   float ytemp = -1*rand()%4 - 8.f;
   float ztemp = -1.0f*(rand()%5) - 10.f;
   float speed = (rand()%20 + 100.f) / 480.0f;

   g_fires[loop].life = 1.5f;
   g_fires[loop].fade = (float) ((rand()%100)/20000 + 0.002);
   g_fires[loop].rad  = (rand()%12 + 24.0f) / 480.0f;

   for (int loop1 = 0; loop1 < MAX_PARTICLES; loop1++) {
      Particle* pat = &g_fires[loop].particle[loop1][0];
      //��ʼ��ɫ
      pat->r = 1.0f; pat->g = 1.0f; pat->b = 1.0f;
      //��ʼλ��
      pat->x = xtemp; pat->y = ytemp; pat->z = ztemp;
      //��ʼ�ٶ�
      pat->xs = 0.0f; pat->ys = speed; pat->zs = 0.0f;
      //��ʼ���ٶ�
      pat->xg = 0.0f; pat->yg = -0.5f/480.0f; pat->zg = 0.0f;
      pat->up = true;

      //β����ʼ��
      for(int loop2 = 1; loop2 < MAX_TAILS; loop2++) {
         pat = &g_fires[loop].particle[loop1][loop2];
         pat->x = g_fires[loop].particle[loop1][0].x;
         pat->y = g_fires[loop].particle[loop1][0].y;
         pat->z = g_fires[loop].particle[loop1][0].z;
      } //for loop2 end
   }//for loop1 end
}

bool Initialize(GLWindow* glwin) {
  g_glwin = glwin;

  if (!LoadGLTexture()) {
    return false;
  }

  glEnable(GL_TEXTURE_2D);
  glShadeModel(GL_SMOOTH);   // enables smooth shading
  glClearColor(0.0f, 0.0f, 0.0f, 0.0f); // black background
  glClearDepth(1.0f);     // depth buffer setup
  //glEnable(GL_DEPTH_TEST);// enables depth testing
  //glDepthFunc(GL_LEQUAL); // the type of depth test to do
  glDisable(GL_DEPTH_TEST);
  glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST); // really nice perspective calculations
  glHint(GL_POINT_SMOOTH_HINT, GL_NICEST);

  glEnable(GL_BLEND);
  glBlendFunc(GL_SRC_ALPHA, GL_ONE);

  for(int loop = 0; loop < MAX_FIRES; loop++) {
    ResetFire(loop);
  }
  return true;
}

void Deinitialize() {
  glDeleteTextures(2, g_texnames);
}

void Selection() {
  return;
}

bool Update() {
  DWORD dt = FPS::Instance()->difftime();

  if (g_glwin->keys[VK_ESCAPE]) {
    g_glwin->keys[VK_ESCAPE] = false;
    TerminateApplication(g_glwin);
    return false;
  }

  if (g_glwin->keys[VK_F1]) {
    g_glwin->keys[VK_F1] = false;
    ToggleFullscreen(g_glwin);
    return false;
  }
 
  if (g_glwin->keys[VK_ADD] && g_speed < 600.0f) {
    g_speed += 1.0f;
  }
  if (g_glwin->keys[VK_SUBTRACT] && g_speed > 6.0f) {
    g_speed -= 1.0f;
  }
  if (g_glwin->keys[VK_PRIOR]) {
    g_zoom += 0.1f;
  }
  if (g_glwin->keys[VK_NEXT]) {
    g_zoom -= 0.1f;
  }

  if (g_glwin->keys[VK_RETURN] && !g_rtpressed) {
    g_rtpressed = true;
    g_brainbow = !g_brainbow;
  }
  if (!g_glwin->keys[VK_RETURN]) {
    g_rtpressed = false;
  }

  if (g_glwin->keys[' '] && !g_sbpressed || g_brainbow && g_delay > 25) {
    if (g_glwin->keys[' ']) {
      g_brainbow = false;
    }
    g_sbpressed = true;
    g_delay = 0;
    g_currentcolor = (g_currentcolor + 1) % 12;
  }
  if (!g_glwin->keys[' ']) {
    g_sbpressed = false;
  }

  if (g_glwin->keys[VK_UP] && g_yspeed < 200) {
    g_yspeed += 1.0f;
  }
  if (g_glwin->keys[VK_DOWN] && g_yspeed > -200) {
    g_yspeed -= 1.0f;
  }
  if (g_glwin->keys[VK_RIGHT] && g_xspeed < 200) {
    g_xspeed += 1.0f;
  }
  if (g_glwin->keys[VK_LEFT] && g_xspeed > -200) {
    g_xspeed -= 1.0f;
  }

  if (g_glwin->keys[VK_TAB])	{ // Tab Key Causes A Burst
    for (int loop = 0; loop < MAX_FIRES; loop++) {
      ResetFire(loop);
    }
  }

  g_delay++;
  return true;
}

bool Draw() {
  float dt = FPS::Instance()->difftime() * 0.001f;
  float factor = dt * g_speed;

  glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);		// Clear Screen And Depth Buffer
  glLoadIdentity();		// Reset The ModelView Matrix

  // ������ɫ���̻���ɫ�仯
  float rgb_max_value = 0.0f;
  for(int loop = 0; loop < MAX_FIRES; loop++) {
    Particle& p = g_fires[loop].particle[0][0];
    float rgb_value = p.r + p.g + p.b;
    if (rgb_value > rgb_max_value) {
      rgb_max_value = rgb_value;
      glColor4f(p.r, p.g, p.b, 1.0f);
    }
  }

  glBindTexture(GL_TEXTURE_2D, g_texnames[1]);
  glBegin(GL_TRIANGLE_STRIP);  // Build Quad From A Triangle Strip

  float h = 0.04142135623730950488016887242097f; // h = tan(45.f/2) * 0.1f;
  float w = h * g_glwin->init.width / g_glwin->init.height;

  glTexCoord2d(1,1); glVertex3f(w, h, -0.1f); // Top Right
  glTexCoord2d(0,1); glVertex3f(-w, h, -0.1f); // Top Left
  glTexCoord2d(1,0); glVertex3f(w, -h, -0.1f); // Bottom Right
  glTexCoord2d(0,0); glVertex3f(-w, -h, -0.1f); // Bottom Left
  glEnd(); // Done Building Triangle Strip

  glBindTexture(GL_TEXTURE_2D, g_texnames[0]);
  for(int loop = 0; loop < MAX_FIRES; loop++) {
    int color = rand()%12;
    for (int loop1 = 0; loop1 < MAX_PARTICLES; loop1++) {
      for(int loop2 = 0; loop2 < MAX_TAILS; loop2++) {
        float x = g_fires[loop].particle[loop1][loop2].x;
        float y = g_fires[loop].particle[loop1][loop2].y;
        float z = g_fires[loop].particle[loop1][loop2].z + g_zoom;
        float dt = 1 - (float)loop2/MAX_TAILS;
        glColor4f(g_fires[loop].particle[loop1][0].r, 
          g_fires[loop].particle[loop1][0].g, 
          g_fires[loop].particle[loop1][0].b, 
          g_fires[loop].life * dt);

        float size = 0.5f * dt;
        glBegin(GL_TRIANGLE_STRIP);   // Build Quad From A Triangle Strip
        glTexCoord2d(1,1); glVertex3f(x+size,y+size,z); // Top Right
        glTexCoord2d(0,1); glVertex3f(x-size,y+size,z); // Top Left
        glTexCoord2d(1,0); glVertex3f(x+size,y-size,z); // Bottom Right
        glTexCoord2d(0,0); glVertex3f(x-size,y-size,z); // Bottom Left
        glEnd(); // Done Building Triangle Strip
      }

      // update position
      for(int loop2 = MAX_TAILS-1; loop2 > 0; loop2--) {
        g_fires[loop].particle[loop1][loop2].x = g_fires[loop].particle[loop1][loop2-1].x;
        g_fires[loop].particle[loop1][loop2].y = g_fires[loop].particle[loop1][loop2-1].y;
        g_fires[loop].particle[loop1][loop2].z = g_fires[loop].particle[loop1][loop2-1].z;
      } //for loop2 end

      g_fires[loop].particle[loop1][0].x += g_fires[loop].particle[loop1][0].xs * factor;
      g_fires[loop].particle[loop1][0].y += g_fires[loop].particle[loop1][0].ys * factor;
      g_fires[loop].particle[loop1][0].z += g_fires[loop].particle[loop1][0].zs * factor;

      // update y speed
      float yd = g_fires[loop].particle[loop1][0].yg * factor;
      g_fires[loop].particle[loop1][0].ys += yd;
      if (g_fires[loop].particle[loop1][0].up && g_fires[loop].particle[loop1][0].ys < -yd) {
        g_fires[loop].particle[loop1][0].up = false;
        //int color = rand()%12;
        g_fires[loop].particle[loop1][0].r = colors[color][0];
        g_fires[loop].particle[loop1][0].g = colors[color][1];
        g_fires[loop].particle[loop1][0].b = colors[color][2];

        // x-z speed
        double radian = 3.14159*loop1*15.0/180.0;
        g_fires[loop].particle[loop1][0].xs = (float)(g_fires[loop].rad*sin(radian));
        g_fires[loop].particle[loop1][0].zs = (float)(g_fires[loop].rad*cos(radian));
      }

      if (g_glwin->keys[VK_UP] && g_fires[loop].particle[loop1][0].yg < 1.5f) {
        g_fires[loop].particle[loop1][0].yg += 0.01f;
      }

      if (g_glwin->keys[VK_DOWN] && g_fires[loop].particle[loop1][0].yg > -1.5f) {
        g_fires[loop].particle[loop1][0].yg -= 0.01f;
      }

      if (g_glwin->keys[VK_LEFT] && g_fires[loop].particle[loop1][0].xg < 1.5f) {
        g_fires[loop].particle[loop1][0].yg += 0.01f;
      }

      if (g_glwin->keys[VK_RIGHT] && g_fires[loop].particle[loop1][0].xg > -1.5f) {
        g_fires[loop].particle[loop1][0].yg -= 0.01f;
      }
    }

    g_fires[loop].life -= g_fires[loop].fade;
    if (g_fires[loop].life < 0) {
      ResetFire(loop);
    }
  }

  return true;
}
